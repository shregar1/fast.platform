"""Vault secrets subsection."""

from __future__ import annotations

from pydantic import ConfigDict

from .abstraction import IDTO


class VaultSecretsDTO(IDTO):
    model_config = ConfigDict(extra="ignore")
    enabled: bool = False
    url: str = ""
    token: str = ""
    mount_point: str = "secret"
